import http from 'k6/http';
import { check } from 'k6';

// Ini pengaturan utamanya (Sesuai gambar Anda: 1000 concurrent)
export const options = {
  vus: 1000,       // 1000 Virtual Users (berjalan bersamaan)
  duration: '5s',  // Serang selama 5 detik
};

export default function () {
  const url = 'https://api-library-be.leapcell.app/api/auth/login';
  const payload = JSON.stringify({
    email: 'makanan@email.com',
    password: 'testing123',
  });
  
  const params = {
    headers: { 
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
  };

  // Tembak API
  const res = http.post(url, payload, params);

  // Pantau Status Code (Sesuai gambar Anda)
  check(res, {
    'Status 200 OK': (r) => r.status === 200,
    'Tidak ada Error 500': (r) => r.status !== 500,
    'Tidak ada Error 502/503': (r) => r.status !== 502 && r.status !== 503,
  });
}